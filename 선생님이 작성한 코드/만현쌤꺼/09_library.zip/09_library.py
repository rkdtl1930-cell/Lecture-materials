# 파일명 : 09_library.py

# 라이브러리(library) : 도서관처럼 내가 필요한 정보(데이터,함수)를 모듈에서 가져와서 사용
# 내가 만들어서 사용 - 모듈
# 남이 만든것을 사용 - 라이브러리

# 표준 라이브러리 - 파이썬 언어를 설치할 때 자동으로 같이 설치되는 라이브러리

# 표준 라이브러리 1. datetime.date() - 년, 월, 일 을 인수로 받아서 날짜로 사용하는 함수
import datetime

day1 = datetime.date(2021,12,14) # day1 에는 2021년 12월 14일이라는 데이터가 저장된다.
day2 = datetime.date(2023, 4, 5) 
# 디데이 구하기
diff_day = day2 - day1 # datetime객체끼리 연산을 하면 일(day) 기준으로 연산을 한다.
print(f"차이나는 일 수 : {diff_day.days}일")
# 내가 지정한 날짜의 요일 알아보기
day = datetime.date(2025, 8, 10)
print(day.weekday()) # weekday()를 사용하면 월-0 ~ 일-6
print(day.isoweekday()) # isoweekday()를 사용하면 월-1 ~ 일-7

# 표준 라이브러리 2. time - 시간관련해서 보여주는 라이브러리
import time
tt = time.time() # 1970년 1월 1일 0시 0분 0초 기준으로 현재까지의 시간을 초 단위로 리턴
print(tt)
lt = time.localtime(tt) # 작성된 초 단위의 데이터를 계산해서 연,월,일,시,분,초 등의 데이터를 객체로 알려준다.
print(lt)
print(lt.tm_year) # localtime이 반환한 객체의 객체 변수(tm_year)를 불러온다.
print(lt.tm_mon)  # 변수들을 하나씩 불러와서 사용할 수 있다.

at = time.asctime(lt) # localtime이 반환한 객체를 보기좋게 문자열로 변경해준다.
print(at)
print(type(at))
ct = time.ctime() # 현재 시간을 문자열로 보여준다.
print(ct)
sft = time.strftime("%Y %m %d %a", lt) # 내가 지정한 형식에 따라서 lt를 보여준다.
print(sft)
# %a	요일의 줄임말
# %A	요일
# %b	달의 줄임말
# %B	달
# %c	날짜와 시간
# %d	일(day)
# %H	시간(24시간)
# %l	시간(12시간)
# %j	1년 중 누적날짜
# %m	달(1월~12월)
# %M	분(00분~59분)
# %p	AM / PM
# %S	초(00초~59초)
# %U	1년 중 누적 주 일요일 시작(0~53)
# %w	숫자로된 요일 ( 0(일) ~ 6(토) )
# %W	1년 중 누적 주 월요일 시작(0~53)
# %x	설정된 지역에 기반한 날짜
# %X	설정된 지역에 기반한 시간
# %Y	연도
# %Z	시간대 , %%	문자 %
# %y	세기 부분을 제외한 연도 출력

# time.sleep(초) - 일정 시간(초)동안 명령을 멈췄다가 실행하게 한다
#                - 반복문에서 자주 사용할 수 있다.
# for i in range(1, 11):
#   print(i)
#   time.sleep(1)

# 표준 라이브러리 3. math ( 수학적인 라이브러리 - gcd, lcm )
import math
print(math.gcd(60, 80, 100))
# gcd() = 최대공약수, 지정한 숫자들의 최대공약수를 구해준다.
#         파이썬 3.5버전 이상부터 사용가능, 파이썬 3.9버전부터는 3개 이상의 인수가 허용 / 이전엔 2개까지만
print(math.lcm(2,3,5))
# lcm() = 최소공배수, 지정한 숫자들의 최소공배수를 구해준다.
#         파이썬 3.9버전 이상부터 사용가능

# 표준 라이브러리 4. random - 난수(랜덤한 값) 출력
import random
print(random.random()) # 0 ~ 1 사이의 난수를 출력한다.
print(random.randint(1, 10)) # 1 ~ 10 사이의 정수인 난수를 출력한다.
data = [ 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
random_data = random.sample(data, 3) # 리스트, 튜플 등 자료구조 객체에서 n개의 요소를 무작위로 뽑아낸다.
print(random_data)
random_one = random.choice(data) # 리스트, 튜플 등 자료구조 객체에서 1개의 요소를 무작위로 뽑아낸다.
print(random_one)

# 표준 라이브러리 5. itertools ( 반복가능객체 관련한 라이브러리 )
import itertools
arr1 = [1,2,3,4,5]
arr2 = ['a', 'b', 'c']
rst1 = zip(arr1, arr2)
print( f"내장함수 zip : {list(rst1)}" )
rst2 = itertools.zip_longest(arr1, arr2, fillvalue="없음")
# 내장함수 zip 과 동일한 동작이지만, 두 객체의 길이가 다를 경우 fillvalue로 채워넣어줄 수 있다.
print( f"itertools.zip_longest : {list(rst2)}")

arr1 = [1, 2, 3]
rst1 = itertools.permutations(arr1, 2)
# 반복가능한객체의 요소를 n개 뽑았을 때 나올 수 있는 순열
print(list(rst1))
rst1 = itertools.combinations(arr1, 2)
# 반복가능한객체의 요소를 n개 뽑았을 때 나올 수 있는 조합
print(list(rst1))
rst1 = itertools.combinations_with_replacement(arr1, 2)
# 반복가능한객체의 요소를 n개 뽑았을 때 나올 수 있는 반복 가능한 조합
print(list(rst1))

# itertools.combinations 예제 - 로또 당첨 확률
lotto = itertools.combinations(range(1,46), 6)
lotto_len = len(list(lotto))
print(lotto_len) # 조합을 찾고, 그 조합의 길이를 구해서 확인할 수 있다.
print(lotto_len * 1000,"원") # 로또의 모든 조합을 샀을 때 나오는 돈 , 81억 4505만원.

# 표준 라이브러리 6. functools ( 함수 )
import functools
data = [1, 2, 3, 4, 5]

def add(x, y):
  return x + y

rst = functools.reduce(add, data)
# 함수를 반복가능한객체의 요소에 차례대로 누적 적용하여 객체를 하나의 값으로 출력하는 함수
# 위의 예제로 동작을 본다면 ((((1+2)+3)+4)+5)
print(rst)

# 표준 라이브러리 7. operator 의 itemgetter
# 주로 sorted 와 같은 함수에서 key 매개변수에 적용하여 기준을 정렬할 수 있도록 도와주는 함수
from operator import itemgetter

students = [
  ("jane", 22, "A"),
  ("dave", 32, "B"),
  ("sally", 17, "B")
]
rst = sorted(students, key=itemgetter(1))
# students 리스트를 정렬하는 데 튜플의 0,1,2 의 인덱스 중 1번 인덱스를 기준으로 정렬
print(rst)

students = [
    {"name": "jane", "age": 22, "grade": 'A'},
    {"name": "dave", "age": 32, "grade": 'B'},
    {"name": "sally", "age": 17, "grade": 'B'},
]
rst = sorted(students, key=itemgetter('age'), reverse=True)
print(rst)

# 표준 라이브러리 8. shutil - 파일을 복사하거나 이동할 때 사용하는 라이브러리(모듈)
import shutil
# shutil.copy("test.txt", "test.txt.bak") # 파일을 복사
# shutil.move("test.txt.bak", "./game/test.txt.bak") # 파일을 이동

# 표준 라이브러리 9. glob - 폴더 내에 파일 찾기 ( 메타 문자 사용 가능 )
#     메타문자란 ? * (글자 수 상관없이) , ? (글자 수 1자)
import glob
print(glob.glob("./test*.txt")) # 현재 폴더의 test + 문자열 + .txt -> 를 찾는다.
print(glob.glob("./test?.txt")) # 현재 폴더의 test + 문자1개 + .txt -> 를 찾는다.

# 표준 라이브러리 10. pickle - 객체를 파일이 쓰고 불러오기 가능한 라이브러리
import pickle
f = open("test1.txt", 'wb')
data = {1 : 'python', 2:'you need'}
pickle.dump(data, f) # data를 f파일에 작성(저장)한다.
f.close()

f = open("test1.txt", 'rb')
data = pickle.load(f) # 저장된 data를 불러와서 변수에 저장
print(data)
f.close()

# 표준라이브러리 11. os - 현재 컴퓨터 시스템의 환경변수나 폴더, 파일 등의 os자원을 제어가능한 라이브러리
import os
# print(os.environ) # 저장된 환경변수를 불러온다.
# print(os.environ['PATH']) # 저장된 환경변수 중에서 PATH 이름의 환경변수를 
print(os.getcwd())
os.chdir("C:/Users/it") # 현재 디렉터리 위치를 변경
print(os.getcwd()) # 현재 디렉터리 위치를 알려준다.
os.chdir("C:/Users/it/Desktop/Python")
os.system("dir") # 시스템 명령어를 파이썬에서 호출
rst = os.popen('dir').read() # 시스템 명령어를 결과값 읽기 모드 형태의 파일 객체로 리턴
print(rst)

# os.mkdir("./HELLO") # 폴더 만들기
# os.rmdir("./HELLO") # 폴더 삭제 , 폴더 안에 파일이 없어야 삭제가 가능하다.
# os.remove("./test123.txt") # 파일 삭제하기
# os.rename("./test12.txt", "test123.txt") # 파일 이름 변경하기

# 표준 라이브러리 12. zipfile - 파일을 zip 형식으로 합치거나 해제할 때 사용
import zipfile

# zip파일로 합치기
with zipfile.ZipFile('myZip.zip', 'w') as myzip:
  myzip.write("./test.txt")
  myzip.write("./test1.txt")

# zip파일 전체 해제하기
with zipfile.ZipFile('myzip.zip') as myzip:
  myzip.extractall("./HELLO")

# zip파일 부분 해제하기(path를 지정하면 지정한 폴더에 해제, 하지 않으면 현재 내 폴더에 해제)
with zipfile.ZipFile('myzip.zip') as myzip:
  myzip.extract('test.txt', path="./HELLO2")

# 파일 합칠 때, 압축하기
with zipfile.ZipFile('mytext.zip', 'w', compression=zipfile.ZIP_LZMA, compresslevel=9) as myzip:
  myzip.write('test.txt')
  myzip.write('test1.txt')
# 압축할 때 설정
# 1. compression 옵션의 4가지 종류
#   ZIP_STORED: 압축하지 않고 파일을 zip으로만 묶는다. 속도가 빠르다.
#   ZIP_DEFLATED: 일반적인 zip 압축으로 속도가 빠르고 압축률은 낮다(호환성이 좋다).
#   ZIP_BZIP2: bzip2 압축으로 압축률이 높고 속도가 느리다.
#   ZIP_LZMA: lzma 압축으로 압축률이 높고 속도가 느리다(7zip과 동일한 알고리즘).
# 2. compresslevel - 1 ~ 9 까지 속도 빠르고 압축률 낮고 -> 속도 느리고 압축률 높고 

# 표준 라이브러리 13. tempfile - 임시 파일 만들 때 사용
import tempfile
filename = tempfile.mkstemp() # 중복되지 않는 임시 파일을 생성하고, 그 파일의 경로를 알려준다.
print(filename)

f = tempfile.TemporaryFile(mode='w+') # 임시적으로 사용가능한 파일 객체를 리턴한다.
f.write("HELLO")
f.seek(0)
print(f.read())
f.close() # close() 하면 파일은 자동적으로 사라지게 된다.

# 표준 라이브러리 14. traceback - 오류 추적할 때 사용하는 모듈
import traceback
def a():
  return 1/0  # 에러
def b():
  a()         # a 함수 호출
def main():
  try:
    b()       # b 함수 호출
  except:
    print("<<<<< 오류 발생 >>>>>>")
    print(traceback.format_exc())

main()        # 메인 함수 호출

# 표준 라이브러리 15. json
# json 이란 ? 데이터를 표현하고 저장하고 교환하기 위한 텍스트 기반에 표준 형식
#             객체 = { key : value } / 배열 = [ v1, v2, v3 ]
# 예 ) 사람 - 이름, 나이, 취미
# { 
#   이름 : 홍길동,
#   나이 : 29,
#   취미 : [ 축구, 책, 공부, 게임 ]
# }
import json
with open('./myinfo.json', encoding="utf-8") as f:
  data = json.load(f) # 파일의 json 형태를 불러와서 변수에 저장

print(data)
print(type(data)) # 딕셔너리 형태로 저장이 된다.

with open('./myinfo2.json', 'w') as f:
  json.dump(data, f) # 작성 시, 한글은 유니코드로 작성이 된다. 읽어올 땐 상관없음

json_data = json.dumps(data) # 파일에 저장이 아닌 문자열로 받기
print(json_data)
json_data_no_ascii = json.dumps(data, ensure_ascii = False)
print(json_data_no_ascii)

# 외부 라이브러리 ( 명령 프롬프트(cmd) 창에서 진행 )
# pip - 파이썬 모듈이나 패키지를 쉽게 설치할 수 있도록 도와주는 도구
# pip list - 설치된 패키지들의 목록
# pip install [패키지명] - 패키지명의 라이브러리를 설치
# pip install [패키지명]==[버전] - 패키지명의 라이브러리 중에서 버전에 맞는 패키지를 설치
# pip install --upgrade [패키지명] - 이미 설치한 패키지를 버전 업그레이드 한다.
# pip uninstall [패키지명] - 패키지명의 라이브러리를 삭제

# 외부 라이브러리 - faker 외부 라이브러리 사용
# faker 라이브러리 = 테스트용 가짜 데이터를 생성할 때 사용하는 라이브러리
# 1. faker 라이브러리 설치 cmd 에 작성
# pip install faker
from faker import Faker
fake_data = Faker()
print(f"무작위로 생성한 이름 : {fake_data.name()}")
fake_ko_data = Faker('ko-KR')
print(f"무작위로 생성한 한글 이름 : {fake_ko_data.name()}")
print(f"무작위로 생성한 한글 주소 : {fake_ko_data.address()}")
# 위 무작위 생성을 이용해서 30건의 리스트를 만들기
# 리스트 만들때는 리스트 컴프리헨션을 사용
test_data = [(fake_ko_data.name(), fake_ko_data.address()) for i in range(0, 30)]
print(test_data)
# Faker로 만들 수 있는 형식들
# fake.name()				      이름
# fake.address()				  주소
# fake.postcode()				  우편 번호
# fake.country()				  국가명
# fake.company()				  회사명
# fake.job()					    직업명
# fake.phone_number()			휴대전화번호
# fake.email()				    이메일 주소
# fake.user_name()				사용자명
# fake.pyint(min_value=0,max_value=100) 	0부터 100 사이의 임의의 숫자
# fake.ipv4_private()				ip 주소
# fake.text()				        임의의 문장
# fake.catch_phrase()				한글 임의의 문장
# fake.color_name()				  색상명

# 외부 라이브러리 sympy - 방정식 기호를 사용할 수 있게 만들어주는 외부 라이브러리
#                fractions - 분수(분자/분모)를 사용할 수 있게 만들어주는 표준 라이브러리
from fractions import Fraction
import sympy

# 예제 ) 학생이 가진 돈의 2/5 로 학용품을 샀다. 그러고 남은 돈이 1760원이면 가진 돈은 얼마였을까?
# 학생이가 가진 돈 = x 
#                   x * 2/5 = 1760
x = sympy.symbols("x")
f = sympy.Eq(x * Fraction(2, 5), 1760) # x * 2/5 = 1760 이라는 방정식
rst = sympy.solve(f) # 위의 방정식의 결과를 리스트로 반환해준다.
print(f"학생이 원래 가진 돈 = {rst}")
print(f"학생이 학용품을 사고 남은 돈 = {rst[0] - 1760}")

# 예제 ) x제곱 = 1 의 해를 구하기
x = sympy.symbols("x")
f = sympy.Eq(x**2, 1) # x의 제곱 = 1 이라는 방정식이 만들어진다.
rst = sympy.solve(f)
print(rst)

# 심볼 2개 작성 방정식도 2개 작성하는 연립방정식의 해 구하기
# x + y = 10 / x - y = 4 일 때 만족하는 x 와 y의 해를 구하기
x , y = sympy.symbols('x y')
f1 = sympy.Eq(x + y, 10) # x + y = 10 이라는 방정식이 만들어진다.
f2 = sympy.Eq(x - y, 4)  # x - y = 4 라는 방정식이 만들어진다.
rst = sympy.solve([f1, f2]) # 두개 이상의 식을 넣어 풀 때는 리스트 형식으로 넣어야한다.
print(rst) # 두 개의 심볼의 해를 구할 때는 딕셔너리 형태로 출력한다. { x : ? , y : ? }