# %%

icecream = { "메로나" : [300, 20], "비비빅" : [400, 3], "죠스바" : [250, 100] }
print(icecream)

print(f"메로나 : {icecream["메로나"][0]}원")
print(f"메로나 : {icecream.get("메로나")[0]}원")

print(f"메로나 : {icecream["메로나"][1]}개")
print(f"메로나 : {icecream.get("메로나")[1]}개")

icecream["월드콘"] = [500, 7]
print(icecream)

print(list(icecream.keys()))

print("더위사냥" in icecream)

del icecream["비비빅"]
print(icecream)

print(icecream.get("브라보콘"))
# %%
print(~5)
print(~7)
print(~10)

# %%
prompt = '''
1. ADD
2. Minus
3. Devide
4. Mul
5. Quit
Enter number :'''
selectNum = -1
while selectNum != '5':
  print(prompt)
  selectNum = input()
  if selectNum == '1':
    print("첫번째 숫자를 입력하세요.")
    num1 = input()
    print("두번째 숫자를 입력하세요")
    num2 = input()
    print(f"{num1} + {num2} = {int(num1) + int(num2)}")
  elif selectNum == '2':
    print("첫번째 숫자를 입력하세요.")
    num1 = input()
    print("두번째 숫자를 입력하세요")
    num2 = input()
    print(f"{num1} - {num2} = {int(num1) - int(num2)}")
  elif selectNum == '3':
    print("첫번째 숫자를 입력하세요.")
    num1 = input()
    print("두번째 숫자를 입력하세요")
    num2 = input()
    print(f"{num1} / {num2} = {int(num1) / int(num2)}")
  elif selectNum == '4':
    print("첫번째 숫자를 입력하세요.")
    num1 = input()
    print("두번째 숫자를 입력하세요")
    num2 = input()
    print(f"{num1} x {num2} = {int(num1) * int(num2)}")
  elif selectNum == '5':
    print("프로그램을 종료합니다.")
  else :
    print("숫자를 잘못입력하셨습니다. 다시 입력해주세요.")

# %%

for i in range(1,6):
    for j in range(1,i+1):
        print("*", end="")
    print()

print()

for i in range(0,5):
    for j in range(i,5):
        print("*", end="")
    print()

print()

for i in range(0,5):
    for j in range(0,5):
        if i + j >= 4 :
            print("*", end="")
        else :
            print(" ", end="")
    print()
print()
for i in range(1,6):
    for j in range(1,6):
        if i > j :
            print(" ", end="")
        else :
            print("*", end="")
    print()

print()
# %%
def print_5xn(str):
   lineNum = int(len(str)/5)
   for x in range(lineNum + 1):
      print(str[x*5 : x *5 + 5])
  
print_5xn("가나다라마바사아자차")
# %%
class Person:
  def __init__(self, name, age, gender):
      self.name = name
      self.age = age
      self.gender = gender
  def __str__(self):
     return f"이름 {self.name} / 나이 {self.age} / 성별 {self.gender}"

class Employee(Person):
  def __init__(self, name, age, gender, eno, dept, sal):
    super().__init__(name, age, gender)
    self.eno = eno
    self.dept = dept
    self.sal = sal
  def __str__(self):
    return super().__str__() + f" / 사원번호 {self.eno} / 부서 {self.dept} / 급여 {self.sal}"

class Student(Person):
  def __init__(self, name, age, gender, sno, major):
    super().__init__(name,age,gender)
    self.sno = sno
    self.major = major
  def __str__(self):
    return super().__str__() + f" / 학생번호 {self.sno} / 전공 {self.major}"
  
hong = Employee("Hong", 45, "남", 123, "개발부", 2000)
son = Student("Son", 20, "남", 123, "컴공")
print(hong)
print(son)
# %%
