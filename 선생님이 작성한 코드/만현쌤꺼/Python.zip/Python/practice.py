# 파일명 : practice.py
# 문제1
#클래스명 : Student
class Student:
  # 학번sno 이름name 전공major 을 초기화하는 생성자를 작성하라
  def __init__(self, sno, name, major):
    self.sno = sno
    self.name = name
    self.major = major
  # 전공을 변경하는 함수를 작성하라
  def changeMajor(self, new_major):
    self.major = new_major
  # 학생 정보(sno name major)을 출력하는 함수를 작성하라
  def __str__(self):
    return f"{self.name} 학생의 학번은 {self.sno} 이고 전공은 {self.major}입니다."

s1 = Student(1, '홍길동', '컴공')
print(s1)
s1.changeMajor('인공지능')
print(s1)

#실행결과
# 홍길동 학생의 학번은 1 이고 전공은 컴공입니다.
# 홍길동 학생의 학번은 1 이고 전공은 인공지능입니다.



# 문제2
list1 = [['홍길동', 80, 60, 70], 
         ['박경미', 90, 95, 80],
         ['정희선', 75, 80, 100],
         ['임혜동', 80, 70, 95]]
# 위 리스트를 가지고 아래의 실행결과를 도출해내라.
print("이름\t국어\t영어\t수학\t총점\t평균")
print("=============================================")
for a in list1:
  print(f"{a[0]}\t{a[1]}\t{a[2]}\t{a[3]}\t{sum(a[1:4])}\t{sum(a[1:4])/3:0.1f}")
# [실행결과]
# 이름    국어    영어    수학    총점    평균
#============================================
#홍길동   80      60      70      210   70.0
#박경미   90      95      80      265   88.3
#정희선   75      80      100     255   85.0
#임혜동   80      70      95      245   81.7 