# 파일명 : 03_data_structure.py

# %%

# 자료구조 1. 리스트
# 선언 변수명 = [ 값1 , 값2 , 값3 , ... ]
a = []                        # 빈 리스트 선언
b = [1,2,3]                   # 숫자만 가지고 선언
c = ['Life', 'is', 'short']   # 문자열만 가지고 선언
d = [1, 2, 'Lift','is']       # 숫자와 문자열 섞어서 선언
e = [1, 2, 3, ['a','b','c']]  # 리스트 안의 리스트도 가능

# 리스트에 접근하기
a = [1, 2, 3, 'a', 'b', 'c']
print(a[0])     # 인덱스를 사용해서 접근 가능
print(a[1])
print(a[-2])
print(a[-1])    # 음수를 인덱스로 사용하면 마지막부터

# 중첩 리스트인 경우 접근하기
a = [1, 2, 3, ['a', 'b', 'c']]
print(a[3]) # 리스트에 접근
print(a[3][0]) # 접근한 리스트에서 다시 인덱스로 또 접근

# 리스트 슬라이싱
print(a[0:3:2]) # 0부터 3번 전까지 2칸씩 출력한다
print(a[1:])    # 1번부터 끝까지 (end 칸에 미입력)
print(a[:3])    # 처음부터 3번 전까지(start 칸에 미입력)

# 리스트 연산 ( + , * )
a = [1, 2, 3]
b = ['a', 'b', 'c']
print( a + b ) # 리스트끼리 더해져서 출력
print( a * 2 ) # 본인 리스트를 복사해서 붙인다

# 리스트 삭제하기 ( del 키워드 사용 )
del a[1]
print(a) # 인덱스 1번 자리의 2 가 삭제되었다.
del b[0:2] # 슬라이싱으로도 삭제가 가능
print(b)

# 리스트 관련 함수 
# 1. append(값) - 요소 추가하기
a = [1, 2, 3]
a.append(4)     # 추가할 요소는 하나만 가능
print(a)
a.append([0,9]) # 리스트도 추가 가능
print(a)
# 2. sort() - 요소를 정렬
a = [0, 4, 2, 3]
a.sort() # 요소(값) 기준으로 정렬
print(a)
# 3. reverse() - 리스트를 역순으로 뒤집어줌
a.reverse()
print(a)
# 4. index(값) - 요소(값)를 기준으로 첫번째 값의 인덱스를 알려줌
a = [0,1,2,3,4,1,2,3,4]
print(a.index(1)) # data 1을 기준으로 첫번째 위치를 찾아준다.
                  # 찾으려는 데이터가 리스트에 없으면 에러를 발생
# 5. insert(위치, 값) - 입력한 위치 앞에 값을 삽입
a = [4,5,6,7]
a.insert(1, 3) # a[1] 의 앞에 3을 삽입한다
print(a)
# 6. remove(값) - 리스트의 첫번째 요소(값)을 삭제한다
a = [1,2,3,4,1,2,3,4]
a.remove(2) # 리스트의 첫번째 2 값을 삭제
print(a)    # 1 3 4 1 2 3 4 가 남게된다.
# 7. pop(인덱스) - 리스트의 인덱스 위치를 출력하고, 삭제한다
print(a.pop(3)) # a[3] 인 1을 출력하고, 원래 리스트에서 삭제
print(a)        # 1 3 4 2 3 4 가 남게된다
# 8. count(값) - 요소(값)을 기준으로 리스트에 몇 개가 있는지 출력
print(a.count(3)) # 3 값을 기준으로 갯수를 출력 2 가 출력된다.
# 9. extend(리스트) - 기존 리스트에 리스트를 더함
a = [1, 2, 3]
a.extend([4,5])
print(a)
a = a + [6,7] # extend 함수와 동일함
# 위의 식을 다르게 작성하면 a += [6,7] 이 된다.
print(a)

# 비어있는 리스트(study)를 선언하고,
study = []
# HTML , JS , CSS 를  삽입하고 출력,
study.append("HTML")
study.append("JS")
study.append("CSS")
print(study) 
# [JAVA, SPRING] 을 삽입하고 출력,
study.append(["JAVA", "SPRING"])
print(study)
# SPRING 의 값을 Spring으로 변경하고 출력,
study[3][1] = "Spring"
print(study)
# JS 를 출력하면서 삭제,
print(study.pop(1))
print(study)
# [Python, Django] 를 추가하고 출력,
study.append(["Python", "Django"])
print(study)
# R 을 CSS 앞에 추가하고 출력
study.insert(1, "R")
print(study)

# %%

# 자료구조 2. 튜플
# 리스트와 유사한 구조
# 데이터의 변경 또는 삭제가 불가능한 자료 구조
# 리스트와 같이 인덱스, 슬라이싱으로 접근 가능
# len(튜플변수명) 함수를 이용해서 길이를 구할 수 있다.
# 튜플은 데이터가 절대 변하지 않는 리스트(배열)을 사용할 때 쓴다.
tuple1 = ()
tuple2 = (1,2,3)
tuple3 = 1,2,3
tuple4 = (1, 2, 3, ('a', 'b'))

print(tuple4 + tuple2)
print(tuple2 * 3)
print(len(tuple4))

#del tuple2[1] # 삭제 명령 실행하면 에러 / 주석 처리
#tuple2[1] = 3 # 값 수정 명령 실행하면 에러 / 주석 처리

# 자료구조 3. 딕셔너리
# key : value 의 쌍으로 이루어진 자료 구조
# 데이터(value)에 접근할 때 인덱스가 아니라 key 로 접근
# 선언 { k1 : v1 , k2 : v2 , ... }
dict1 = {'name' : '홍길동', 'phone' : '01012341234', 'birth' : '830830'}
# key 와 value 추가
# 가지고 있지 않은 key를 적고 value를 할당시키면 key와 value 쌍이 추가된다.
dict1['age'] = 43
print(dict1)
# key 와 value 삭제 ( del 키워드 사용 )
del dict1['age']
# 딕셔너리의 데이터 접근 ( 인덱스 대신 키를 사용해서 접근 )
print(dict1['name'])
# *****주의사항******
# 같은 key를 작성하면 작성한 것 중 마지막 value 하나만 key와 mapping이 된다.
# 리스트는 key로 사용할 수 없다.

# 딕셔너리 함수 1. keys - key들만 모아서 출력(dict_keys라는 객체에 리스트로 담아서 출력)
print(dict1.keys())

key_list = list(dict1.keys()) # dict1.keys() 로 받은 dict_keys를 list로 변환
print(key_list)               # 인덱스로 key 값에 접근 가능
print(key_list[1])

# 딕셔너리 함수 2. values - value들만 모아서 출력(dict_keys라는 객체로)
print(dict1.values())

value_list = list(dict1.values()) # values도 list로 변경해서 접근 가능
print(value_list)
print(value_list[1])

# 딕셔너리 함수 3. items - key, value를 튜플로 묶어서 dict_keys라는 객체에 리스트로 담음
print(dict1.items())

# 딕셔너리 함수 4. in - Key를 기준으로 딕셔너리 내에 있는지 T/F 출력
print('name' in dict1)
print('age' in dict1)

# 딕셔너리 함수 5. get - Key를 기준으로 value 얻기
print(dict1.get('name')) # key가 name 인 value를 얻어온다.
print(dict1['name'])
print(dict1.get('age')) # 없는 key를 썼을 때 None 을 출력
# print(dict1['age']) # 없는 key를 썼을 때 에러를 출력
print(dict1.get('age', "no value")) # 없는 key 값을 적을 때 반환할 기본 값을 지정할 수 있다

# 딕셔너리 함수 6. clear() - 딕셔너리 내의 모든 key:value 쌍을 삭제
dict1.clear()
print(dict1)

# 딕셔너리 변수명 : icecream
# 아이스크림 이름이 key / [가격, 재고] value
# 메로나 300원 20개
# 비비빅 400원 3개
# 죠스바 250원 100개
icecream = { "메로나" : [300, 20], "비비빅" : [400, 3], "죠스바" : [250, 100] }
print(icecream)

# 메로나의 가격을 화면에 출력하라 ( 출력 -> 메로나 : 300원 )
print(f"메로나 : {icecream.get("메로나")[0]}원")

# 메로나의 재고를 화면에 출력하라 ( 출력 -> 메로나 : 20개  )
print(f"메로나 : {icecream["메로나"][1]}개")

# 월드콘 500원 7개 를 딕셔너리에 추가
icecream["월드콘"] = [500, 7]
print(icecream)

# key값들만 불러오기 -> 리스트형태로 불러오기
print(list(icecream.keys()))

# 더위사냥이 딕셔너리 안에 있는지(T) 없는지(F) 출력
print("더위사냥" in icecream)

# 비비빅 을 딕셔너리에서 제거
del icecream["비비빅"]
print(icecream)

# 브라보콘 의 정보를 불러오기 ( 없어도 에러가 나지 않게 )
print(icecream.get("브라보콘"))

# %%

# 자료구조 4. 집합(set)
# 집합 구조를 쉽게 처리하기 위해 만든 자료형
# 선언 ( set 키워드를 사용해서 생성 )
set1 = set([1, 2, 3])
print(set1)
set2 = set("Hello")
print(set2)
# set2 의 결과를 보면 중복이 허용되지 않아서 요소가 l H o e 밖에 없다.
# set2[0] 좌측에 코드를 입력해보면 에러 표시
#         set은 순서가 없기 때문에 인덱싱이 불가능하다.
#         인덱싱을 하려면 list() 나 tuple()을 사용해야한다.

# 교집합(&) 합집합(|) 차집합(-) 구하기
s1 = set([1,2,3,4,5,6]) 
s2 = set([4,5,6,7,8,9])
# 교집합
print(s1 & s2)
print(s1.intersection(s2))
# 합집합
print(s1 | s2)
print(s1.union(s2))
# 차집합 ( 왼쪽 피연산자를 기준으로 오른쪽 피연산자의 차집합을 구한다 )
print(s1 - s2)
print(s2 - s1)
print(s1.difference(s2))
print(s2.difference(s1))

# 값 추가하기 ( 1개 )
s1.add(7)
print(s1)
# 값 추가하기 ( 여러개 )
s1.update([8,9,10]) # 연속성이 있는 자료형을 넣어야하기 때문에 리스트(튜플)를 넣어야한다.
print(s1)
s1.update((11,12,13))
print(s1)
# 특정 값 제거하기 ( 1개만 )
s1.remove(11)
print(s1)


# 자료구조 5. 불(bool) 자료형
# 참(True) / 거짓(False) 의 값만 나타내는 자료형
# 문자열의 빈값('') 또는 숫자의 0 또는 리스트,튜플,딕셔너리,집합의 빈값을 제외하고는 모두 TRUE
# None = False

# %%

# 변수란 ?
# 데이터 또는 객체를 담는 메모리를 생성하여 저장하는 곳
# 변수는 메모리의 주소와 데이터 또는 객체를 담고 있다
# 변수 선언 ( 변수명 = 변수에 대입할 값 또는 객체)
variable = 300
# 변수의 메모리 주소 확인 ( id(변수명) 함수 사용)
print(id(variable))
# 새로운 변수에 기존 변수를 넣으면 값 뿐만아니라 주소도 복사 된다.
var2 = variable
var3 = 300
print(id(var2))
print(variable == var2) # == 은 값(data) 비교
print(variable is var2) # is 는 메모리 주소 비교
print(variable == var3)
print(variable is var3)
# 메모리 주소 예외 사항
# Python 에서는 -5 ~ 256 까지 메모리 최적화를 위해 미리 주소를 할당
var4 = 256
var5 = 256
print(var4 == var5) # 값 비교할 때
print(var4 is var5) # None 이나 객체 비교할 때 사용
# 변수 선언 여러가지 방법
# 튜플로 두개의 변수를 한 번에 선언 및 할당 가능하다.
a,b = ('first', 'second')
print(a)
print(b)
# 괄호 생략도 가능
c,d = '1', '2'
print(c)
print(d)
# 리스트 형식도 가능
e,f = ['3','4']
print(e)
print(f)
# 여러 개 변수에 같은 값 대입
a = b = 'test'
print(a)
print(b)
print( a is b ) # 같은 주소를 할당 받는다
a = 'text' # 값(객체) 자체를 변경했을 때는 새로운 메모리 주소를 할당받음
print(a)
print(b)
print(a is b)

a = [1,2,3] # 값(객체) 자체가 아닌 그 속의 하나의 데이터를 바꾼다면 새로운 주소를 받지 않는다.
b = a
print(a)
print(b)
print(a is b)
a[1] = 4
print(a)
print(b)