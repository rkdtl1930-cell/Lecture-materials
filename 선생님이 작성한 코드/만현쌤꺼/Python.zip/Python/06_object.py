# 파일명 : object.py
# %%

# 클래스 : 똑같은 객체를 만들어낼 틀(도면)
# 객체 : 클래스를 통해 실제의 데이터를 저장하는 피조물
# 메소드 : 클래스 안에 있는 함수

# 클래스 정의 ( class 클래스명: 아래에 명령문)
# 보통 클래스명을 사용할 때는 첫글자를 대문자(함수와의 차이)
class FourCal:
  pass
# 객체에 클래스 주입 ( 변수명 = 클래스명() )
a = FourCal()
print(type(a))

# 메소드 만들기
class FourCal:
  # 매개변수 3개 중 무조건 첫 번째 매개변수는 객체 자신을 가리킨다.
  def setData(this, first=0, second=0):
    this.first = first
    this.second = second
  def add(self):
    return self.first + self.second
  def sub(self):
    return self.first - self.second
  def mul(self):
    return self.first * self.second
  def div(self):
    return self.first / self.second
  
a = FourCal()
b = FourCal()
a.setData(4, 2)
# setData메소드 실행과 동시에 a객체에 first와 second 변수가 생긴다
b.setData(3, 2)
  # 매개변수 self 는 a 객체 자신을 가리킨다.
  # a.first = 4
  # a.second = 2
print(a.first , " and " , a.second)
print(b.first , " and " , b.second)
print(a.add())
print(a.sub())

c = FourCal()
#c.add() # setData를 해주지않으면 add,mul,sub,div 메소드를 사용할 수 없다.

# 생성자 ( 안에 있는 클래스 주입할 때 변수를 미리 생성 )
class FourCal:
  # __init__ 는 클래스 생성자
  def __init__(self, first=0, second=0):
    self.first = first
    self.second = second
  # __str__ 은 클래스 자체를 부를때 문자열로 출력해준다.
  def __str__(self):
    return f"{self.first} and {self.second}"
  def add(self):
    return self.first + self.second
  def sub(self):
    return self.first - self.second
  def mul(self):
    return self.first * self.second
  def div(self):
    return self.first / self.second

a = FourCal(41,2) # 클래스 주입과 동시에 first 와 second 변수 초기화
b = FourCal()
c = FourCal(10)

print(a) 
# __str__ 메소드가 없을 땐 <__main__.FourCal object at 0x0000021F5E563CB0> 출력
# __str__ 메소드가 있을 땐 작성한 문자열을 반환한다.
# %%

# 클래스 예제 1
# 축구 선수를 클래스로 만들고, 생성자, 문자열반환, 등번호 변경하는 메소드를 구현
class SoccerPlayer:
  # 생성자
  def __init__(self, name, position, back_number):
    self.name = name
    self.position = position
    self.back_number = back_number
  # 등번호 변경
  def change_back_number(self, new_number):
    print(f"선수의 등번호 변경 : {self.back_number} -> {new_number}")
    self.back_number = new_number
  # 문자열반환 ( 정보 출력 )
  def __str__(self):
    return f"이름\t\t{self.name}\n포지션\t\t{self.position}\n등번호\t\t{self.back_number}"

son = SoccerPlayer("Son", "FW", 10)
print(son)
son.change_back_number(7)
print(son)

# 클래스 예제 2
# 학생 클래스를 만든다.
# 생성자를 만든다 ( 변수는 학번 sno 이름 name 성별 gender 전공 major)
# 정보를 출력할 때는 "학번 : sno / 이름 : name / 성별 : gender / 전공 : major"를 출력
# 전공 변경하는 메소드(change_major())를 구현한다.
class Student:
  def __init__(self, sno, name, gender, major):
    self.sno = sno
    self.name = name
    self.gender = gender
    self.major = major
  def __str__(self):
    return f"학번: {self.sno} / 이름: {self.name} / 성별: {self.gender} / 전공: {self.major}"
  def change_major(self, new_major):
    print(f"전공 변경 : {self.major} -> {new_major}")
    self.major = new_major

hong = Student(1, '홍길동', '남', '컴공')
print(hong)
hong.change_major("정보통신")
print(hong)
# %%

# 클래스 특성 1. 상속 - 물려받다
# 작성법 class 클래스명(부모클래스명): 아래에 메소드 정의
class MoreFourCal(FourCal):
  def __init__(self, first, second, third):
    # super() 는 부모의 객체를 가지고 온다
    super().__init__(first, second)
    self.third = third
  def pow(self):
    return self.first ** self.second

a = MoreFourCal(4, 2, 3)
print(a)
print(a.add())
print(a.mul())
print(a.sub())
print(a.div())
# 위 예시처럼 상속 받은 클래스는 부모클래스의 기능을 다 사용할 수 있다.
print(f"third : {a.third}")
print(a.pow())
# 또한, 상속이 아닌 자신의 메소드를 정의하여 사용 가능

# 클래스 특성 2. 메소드 오버라이딩 - 메소드 재정의
# 부모클래스의 메소드를 이름을 똑같이하여 재정의한다.
class SafeFourCal(FourCal):
  def div(self):
    if self.second == 0:
      return 0
    else:
      return self.first / self.second

a = FourCal(4,0)
b = SafeFourCal(4,0)
# print(a.div()) -> 나누기에서 우측 피연산자는 0 이 될 수 없다 에러 출력
print(b.div()) # 우측 피연사자가 0 이면 0 을 출력
# %%

# 상속과 오버라이딩 예제
class Animal:
  def __init__(self, name):
    self.name = name
  def talk(self):
    return "talktalktalk"

class Cat(Animal):
  def talk(self):
    return "Meow!"
class Dog(Animal):
  def talk(self):
    return "Meong!"
  
a = Cat("고양이")
print(a.talk())
b = Dog("멍멍이")
print(b.talk())

# 상속 예제
# 사람person 클래스 ( 이름name, 나이age, 성별,gender)
# 회사원employee클래스
#   이름 나이 성별 사원번호eno 부서dept 급여sal
# 학생student 클래스
#   이름 나이 성별 학생번호sno 전공major
# 각각의 __str__ 변수에 대한 정보를 모두 출력하기
# __init__와 __str__ 모두 super() 사용
class Person:
  def __init__(self, name, age, gender):
    self.name = name
    self.age = age
    self.gender = gender
  def __str__(self):
    return f"이름 {self.name} / 나이 {self.age} / 성별 {self.gender}"

class Employee(Person):
  def __init__(self, name, age, gender, eno, dept, sal):
    super().__init__(name, age, gender)
    self.eno = eno
    self.dept = dept
    self.sal = sal
  def __str__(self):
    return super().__str__() + f" / 사원번호 {self.eno} / 부서 {self.dept} / 급여 {self.sal}"

class Student(Person):
  def __init__(self, name, age, gender, sno, major):
    super().__init__(name,age,gender)
    self.sno = sno
    self.major = major
  def __str__(self):
    return super().__str__() + f" / 학생번호 {self.sno} / 전공 {self.major}"

hong = Employee("Hong", 45, "남", 123, "개발부", 2000)
son = Student("Son", 20, "남", 123, "컴공")
print(hong)
#이름 Hong / 나이 45 / 성별 남 / 사원번호 123 / 부서 개발부 / 급여 2000
print(son)
#이름 Son / 나이 20 / 성별 남 / 학생번호 123 / 전공 컴공
# %%

# 클래스 특성 3. 클래스 변수
class Family:
  lastname = "조" # 클래스 변수 초기화
  def __init__(self, name):
    self.name = name # 객체 변수 초기화
  def __str__(self):
    return f"나의 이름은 {self.lastname} {self.name} 입니다."

a = Family("길동")
b = Family("길순")
c = Family("길종")
print(a)
print(b)
print(c)
Family.lastname = "박" 
# 클래스 변수를 변경하면 모든 객체의 클래스 변수가 바뀐다
print(a)
print(b)
print(c)
a.lastname = "조"
# 클래스 변수를 개별로 변경한다면 더이상의 클래스 변수가 아니라 객체 변수가 된다.
print(a)
print(b)
print(c)
Family.lastname = "하"
print(a) # a 객체는 lastname 이 객체 변수가 되었기 때문에 클래스 변수가 접근 불가
print(b)
print(c)

# 클래스 특성 4. 가시성(visibility) - private ( 접근 불가 )
class Person:
  def __init__(self, name, age, gender):
    self.__name = name # 언더바 2개를 쓰고 변수명을 쓰면 그 변수는 private 이 된다.
    self.age = age
    self.gender = gender
  def about_me(self):
    print(f"name:{self.__name}, age:{self.age}, gender:{self.gender}")
  
  @property # @property 어노테이션을 사용하면 메소드 호출처럼 () 없이 호출 가능(259라인)
  def getName(self):
    return self.__name
    
  @getName.setter
  def setName(self, name):
    self.__name = name
  
hong = Person("hong", "45", "남")
hong.about_me()
#print(hong.__name) # private 이기 때문에 접근할 수가 없다.
print(hong.age)
# print(hong.getName()) 일반적인 메소드 호출
print(hong.getName) # 어노테이션 때문에 () 없이 호출 가능
hong.setName = "pang"
print(hong.getName)