# from module1 import *

# prompt = """사용할 모드를 입력하세요.
# 1. add 2. sub 3. mul 4. div 5. end"""

# while 1:
#   print(prompt)
#   selectNum = input("모드 입력 >> ")
#   if selectNum == '1':
#     num1, num2 = user_input()
#     print(f"{num1} + {num2} = {add(num1,num2)}")
#   elif selectNum == '2':
#     num1, num2 = user_input()
#     print(f"{num1} - {num2} = {sub(num1,num2)}")
#   elif selectNum == '3':
#     num1, num2 = user_input()
#     print(f"{num1} * {num2} = {mul(num1,num2)}")
#   elif selectNum == '4':
#     num1, num2 = user_input()
#     print(f"{num1} / {num2} = {div(num1,num2)}")
#   elif selectNum == '5':
#     print("프로그램을 종료합니다.")
#     break
