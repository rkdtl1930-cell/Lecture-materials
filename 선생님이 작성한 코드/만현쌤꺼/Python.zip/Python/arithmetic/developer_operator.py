def rem(a,b):
  return a % b
def share(a,b):
  return a // b
def power(a,b):
  return a ** b