# cmd ( 명령프롬프트 명령어 )
# dir - 현재 폴더에 있는 파일 및 폴더 목록
# cd - 폴더로 이동

# 처음 보여줄 화면
prompt = '''
1. ADD
2. Minus
3. Devide
4. Mul
5. Quit
Enter number :'''
# 각 번호에 맞게 선택하면 2개의 숫자를 입력받아서
# 각 번호에 맞게 계산하는 프로그램을 작성
# 단, 5번을 입력하면 프로그램이 종료되게 한다.
selectNum = -1
while selectNum != '5':
  print(prompt)
  selectNum = input()
  if selectNum != '5':
    canSelectNum = ['1', '2', '3', '4']
    if selectNum in canSelectNum:
      print("첫 번째 숫자를 입력하세요.")
      num1 = input()
      print("두 번째 숫자를 입력하세요.")
      num2 = input()
      if selectNum == '1':
        print(f"{num1} + {num2} = {int(num1) + int(num2)}")
      elif selectNum == '2':
        print(f"{num1} - {num2} = {int(num1) - int(num2)}")
      elif selectNum == '3':
        print(f"{num1} / {num2} = {int(num1) / int(num2)}")
      elif selectNum == '4':
        print(f"{num1} x {num2} = {int(num1) * int(num2)}")
    else:
      print("번호를 잘못입력했습니다. 다시 입력해주세요.")
  else :
    print("프로그램을 종료하겠습니다.")