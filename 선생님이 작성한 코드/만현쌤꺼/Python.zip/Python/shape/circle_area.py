PI = 3.141592
def circle_area(r):
  return PI * (r ** 2)