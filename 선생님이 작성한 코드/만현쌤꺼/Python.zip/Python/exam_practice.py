# 파일명 : exam_practice.py

# 변수에 데이터 할당하기
a = 10
# 변수에 사용자 입력 값을 할당시키기
a = input()
# input이라는 함수에 프롬프트 넣기
a = input("입력하세요 >> ")
# 입력하세요 >> (사용자 입력)

# 조건문 ( if - elif - else )
# 조건이 2개 일때
# if 조건 : 
#   실행문
# else :
#   실행문
# 조건이 3개 이상일 때
# if 조건 :
#   실행문
# elif 조건2:
#   실행문
# else:
#   실행문
# 조건으로 들어갈 수 있는 값 - true 와 false 를 반환하는 식
#   예 ) 입력 받은 값이 10 이상이다. -> ( input_num >= 10 )

# 문자열 표현
num = 10
# 문자열에 변수를 넣어서 작성
print(f"지금 num변수 값은 {num}입니다.")
# 입력 받은 값이 10 이상이면 "10이상입니다." 10 이하이면 "10이하입니다."
num = input("숫자 입력 >> ")
if int(num) >= 10:
  print("10 이상입니다.")
else :
  print("10 미만입니다.")

# 무한루프를 만들기
# while True:
#    실행문
# 무한루프를 탈출하기
#   break - break키워드를 통해서 탈출이 가능하다
# 예제) 그만 이라고 입력하면 무한루프 탈출하기
while True:
  userStr = input("그만이라고 입력하세요 >> ")
  if userStr == "그만":
    break

# 문자열 자르기
str = "abcd efgh ijk"
str_list = str.split()
print(str_list)
# 문자열을 대문자로 만들기
print(str_list[0].upper())
# 문자열의 길이 구하기
print(len(str_list[2]))

# 반복문 for문
# 리스트나 튜플처럼 반복가능한객체일 경우
for text in str_list: # str_list 의 요소가 하나씩 text에 들어간다.
  print(text.upper())

# 2차원 리스트 만들기
list2 = [ ['a','b','c'], [1, 2, 3]]
print(list2)
print(list2[0]) # [a,b,c]
print(list2[1]) # [1,2,3]
print(list2[1][0]) # 1 
for element1 in list2:
  for element2 in element1:
    print(element2)

# 문자열 출력할 때 칸 맞춰서 출력하기 ( 이스케이프 문자 사용 )
# \t = 8칸
print("이름\t국어\t수학\t영어\t총점\t평균")

# 딕셔너리 선언
dict = {"a" : 1 , "b" : 2 , "c" : 3}
# key = a b c
# value = 1 2 3
# key를 이용해서 value를 불러오기
print(dict["a"])     # 없는 키를 부르면 에러가 난다.
print(dict.get("a")) # key를 이용해서 value를 불러온다. 없는 키를 부르면 None을 반환한다.

print(dict.keys()) # dict가 가지고있는 key를 반환한다.

for key in dict.keys():
  print(dict.get(key))

# 클래스 만들기
class person : # 클래스 선언
  def __init__(self, var1, var2, var3): 
    # 생성자, 클래스를 객체로 만들때 안에 객체 변수를 같이 만든다.
    self.var1 = var1
    self.var2 = var2
    self.var3 = var3
  def make_method(self, var1):
    self.var1 = var1 
    # 생성자처럼 객체변수를 새로 만드는게 아니라, 생성자에서 만든 객체변수의 값을 변경한다.
  def __str__(self):
    return f"{self.var1}이고, {self.var2}이며, {self.var3}이다."
  # 객체를 출력할 때, 보여주는 문자열을 정의한다.

a = person(10,20,30)
print(a)
