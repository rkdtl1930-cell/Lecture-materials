# 파일명 : system_test.py
import sys

args = sys.argv[1:]
print(args)
for i in args:
  print(i)