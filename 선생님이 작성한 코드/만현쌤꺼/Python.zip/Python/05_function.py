# 파일명 : 05_function.py
# %%
# #%% 가 있어야 ctrl+enter 했을 때 왼쪽에 대화형 결과표가 표시됩니다.

# 함수 : 반복되는 행위(명령)이 있을 때 그 행위를 정의해서 호출하여 사용
#       -> 프로그램 흐름을 파악하기 좋고 오류 발생 지점도 찾기 쉽다
# 함수 구조 ( 매개변수와 return문은 생략 가능 )
# def 함수명(매개변수):
#     명령어...
#     return 반환값

# 매개변수 o 리턴 o 함수
def add(a,b):     # 함수 정의 ( function definition )
  result = a + b
  return result
a = add(1,3)      # 함수 호출 ( function call )
# 위의 함수를 보면 매개변수 a,b 에 인수 1,3을 넣어서 
# 더한 다음 결과값 result를 반환해서 a 라는 변수에 할당한다.
print(a)

# 매개변수 x 리턴 o 함수
def say():
  return 'Hello'
a = say()
say()
# 입력값은 없지만 문자열 Hello 라는 값을 반환(return)해서
# a 라는 변수에 할당한다.
print(a)

# 매개변수 o 리턴 x 함수
def add(a, b):
  print(f"{a},{b}의 합은 {a+b}입니다.")
a = add(1,3)
add(1,3)
# 매개변수 a,b 자리에 인수 1,3을 넣어서 명령을 수행한 다음 함수 종료
# 반환값이 없을 때에 a 변수에는 None 이 들어간다. ( 에러 x )
print(a)

# 매개변수 x 리턴 x 함수
def say():
  print("헬로")
a = say() 
say()
# 함수를 실행하면 "헬로"를 출력하고 끝난다.

# 위 예시들에 보면 모두 변수 = 함수호출 형식으로 진행됐는데
# 매개변수가 있든 없든, 리턴값이 있든 없든 함수 호출만하면 함수는 실행된다.
add(2,5)
say()

# 매개변수를 지정해서 함수를 호출
def sub(a,b):
  return a-b
rst = sub(a = 10, b = 5)
print(rst)
rst = sub(b = 10, a = 5) # 매개변수의 순서는 상관없다.
print(rst)

# 몇 개의 인수가 들어올지 모를 때 ( *매개변수 )
def add_many(*nums):
  result = 0
  print(nums) # 입력받은 여러개의 인수 확인용 print - 튜플로 확인
  for num in nums:
    result += num # result = result + num 와 같은 명령문
  return result

rst = add_many(1,2,3,4,5,6,7)
print(rst)

# 여러가지 인수를 받을 때 다른 인수도 받을 수 있다.
def add_mul(choice, *nums):
  if choice == 'a':
    result = 0
    for i in nums:
      result += i
  elif choice == 'm':
    result = 1
    for i in nums:
      result *= i
  return result

rst_a = add_mul('a', 1,2,3,4,5)
rst_m = add_mul('m', 1,2,3,4,5)
print(rst_a)
print(rst_m)

# keyword=value 형식으로 인수를 받을 때
# 인수를 key=value 형식으로 입력하고, 변수에는 딕셔너리 형태로 저장 
def print_kwargs(**kwargs):
  print(kwargs)
  for k,v in kwargs.items():
    print(f"{k} is {v}")

print_kwargs(a=1)
print_kwargs(name='foo', age=3)

# 리턴값은 하나이다.
def add_and_mul(a,b):
  return a+b, a*b
result = add_and_mul(3,4)
print(result) # return을 2개 작성해도 튜플 형식으로 하나로 반환함
rst1, rst2 = add_and_mul(3,4)
  # 변수도 2개를 작성해서 하나씩 받을 수 있다. 변수 선언 방식 중 1개
print(rst1, " and ", rst2)
# 리턴문 2개 작성
def add_and_mul(a,b):
  return a+b  # return 문 = 종료 라는 뜻이기 때문에
  return a*b  #             2줄을 적어도 위에 부분만 적용

# 매개변수의 기본값 지정하기 
#   *** 기본값 지정은 맨 마지막 매개변수로 *** (syntax error 문법 에러)
#        -> 인수를 넣을 때 기본값인지 아닌지 판단하기 어렵기 때문
def introduce(name, age, man=True):
  print(f"이름 : {name}")
  print(f"나이 : {age}")
  if man:
    print(f"남자입니다.")
  else:
    print(f"여자입니다.")

introduce("홍길동", 30) 
# man이라는 매개변수는 기본값으로 true가 있기 때문에 
# 함수 호출 시 인수를 작성안해도 문제없다.
introduce("박응선", 27, False)
# 기본값과 다른 값을 넣고싶으면 작성하면 된다.


# 함수 안에서 선언한 변수 효력 범위 
# 함수 안의 변수와 함수 밖의 변수는 별개 ( 전역 변수 개념 x )
a = 1
def vartest(hello):
  hello = hello + 1 # hello = 2 
vartest(a) # 밖의 a 라는 변수에게는 효력이 없다.
print(a) # 1

# a 라는 변수를 전역변수로 사용할 때 ( global 키워드 사용 )
def vartest2():
  global a # 내 함수에서 밖의 변수를 사용할 때 global 키워드 사용.
  a = a + 1
vartest2()
print(a) # global a 의 키워드로 인해 밖의 a 변수에 접근 가능

# num을 매개변수로 사용해서 num에 대한 구구단을 출력하는 함수를 만들어봅시다.
# 함수명 = gugudan(num)
# 함수실행하면 num * 1 부터 num * 9 까지 출력하는 함수
def gugudan(num):
  for i in range(1,10):
    print(f"{num} x {i} = {num * i}")

gugudan(2)
gugudan(5)
# %%
# lambda ( 람다 )
# 간단한 return만 있는 함수를 정의할 때 사용.
# 선언 ( 함수이름 = lambda 매개변수 : return문 )
add = lambda x,y : x + y
rst = add(1,2)
print(rst)
# 위 lambda 식을 def 함수 정의로 바꾼다면 아래와 같다
def add_def(x, y):
  return x + y
rst2 = add_def(1,2)
print(rst2)
# %%
# 입출력 함수
# 1. 사용자 입출력 ( input , print )
# input() : 사용자에게 입력받는 함수
# 인수를 넣으면 입력하기 전 안내문구를 띄운다.
number = input("숫자를 입력하세요 >> ")
# print() : 작성하는 문자열을 출력하는 함수

# 2. 파일 입출력
#    1) 파일 열기 open(경로, 모드) / 파일 없으면 생성
#         모드 = w(쓰기) a(추가) r(읽기) 
#         ****** 파일을 open() 했으면 항상 close() 해줘야한다 !!!
# 쓰기
file = open("test.txt", 'w')
for i in range(1, 11):
  data = f"{i}번째 줄 입니다.\n"
  file.write(data)
file.close()
# 추가로 쓰기
file = open("test.txt", 'a')
for i in range(11, 20):
  data = f"{i}번째 줄 입니다.2\n"
  file.write(data)
file.close()
# 읽기 ( readline() - 한 줄 읽기 )
file = open("test.txt", 'r')
line = file.readline() # 한 줄만 읽어온다.
print(line)
file.close()
# readline()을 이용해서 전체 줄 다 읽어오기.
f = open("test.txt", 'r')
while 1:
  line = f.readline() # 마지막 라인에서 ""을 출력
  if not line : break
  print(line)
f.close()
# 읽기 ( readlines() - 한 줄씩 list 형태로 저장)
f = open("test.txt", 'r')
lines = f.readlines() # 각 라인을 요소로 가지는 리스트 형태가 된다.
print(lines)
for line in lines:
  print(line) # 한 줄씩 출력
f.close()
# 읽기 ( read() - 파일 전체 내용을 문자열로 리턴 )
f = open("test.txt", 'r')
data = f.read()
print(type(data))
print(data)
f.close()
# 읽기 ( 파일 자체를 for문 돌리기 )
# 파일이 저장된 변수를 for문을 돌리면 한 줄씩 읽어온다.
f = open("test.txt", 'r')
print(f)
for line in f:
  print(line)
f.close()

f = open("test.txt", "w") # 모드가 w 일 경우 내용을 모두 삭제하고 작성
data = "12345678901234567890"
f.write(data)
f.close()

# 커서를 옮겨서 중간에 write 하기
f = open("test.txt", "r+") # 읽고 쓰기라는 모드
f.seek(5) # 커서를 +5 방향으로 이동한다.
data = f.write("alksfjsklfsajdkf")
f.close()

# with문으로 파일 열고 닫기 ( 장점 : 자동으로 닫아준다 (close를 해준다) )
with open("test.txt", "w") as f:
  f.write("Life is too short, you need python")

# 프로그램 입력 ( 프로그램 실행시킬 때 인수 넣기 )
# 새로운 파일에 작성 ( system_test.py )
# %%
# 입력한 문자열을 한 줄에 다섯글자씩 출력하는 함수를 작성하여라.
# 함수명 : print_5xn(문자열)
# 호출 : print_5xn("가나다라마바사아자차카타파하")
# 출력 : 가나다라마
#        바사아자차
#        카타파하
def print_5xn(str):
  lineNum = int(len(str)/5) 
  for line in range(lineNum + 1):
    print(str[line*5 : line*5 + 5])

print_5xn("가나다라마바사아자차카타파하")

# 입력한 문자열을 한 줄에 다섯글자씩 출력하는 함수를 작성하여라.
# 함수명 : print_n(문자열, 자를문자열의길이)
# 호출 : print_n("가나다라마바사아자차카타파하", 3)
# 출력 : 가나다
#        라마바
#        사아자
#        .....
def print_5xn(str, chunkNum):
  lineNum = int(len(str)/chunkNum) 
  for line in range(lineNum + 1):
    print(str[line * chunkNum : line * chunkNum + chunkNum])

print_5xn("가나다라마바사아자차카타파하", 7)