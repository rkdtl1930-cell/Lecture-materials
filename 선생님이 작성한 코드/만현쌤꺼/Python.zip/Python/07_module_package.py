# -----------------------------------------------------------------------
# 실행 단축키 만들기 ( 대화형 말고 )
# 우측 하단 톱니바퀴 클릭 - 바로가기키 - run python file 검색
# run python file in Terminal 부분 좌측에 + 눌러서 ctrl+enter 누르고
# enter 한 번 더 누르면 키 바인딩 완료.

# 지금까지 # %% 를 이용해서 부분적으로 실행시켰다면,
# 위 설정은 파일 전체를 실행시킨다.
# -----------------------------------------------------------------------

# 파일명 : 07_module_package.py

# 모듈 : 함수, 변수 또는 클래스를 모아놓은 외부 파일
#        다른 파이썬 프로그램에서 불러와 사용하는 외부 파일
# 모듈 만들기 ( 외부 파일 module1.py 작성 )
# 모듈 불러오기 ( 모듈을 불러올 때는 .py는 작성하지 않는다, 이름만 작성 )
# 1. 모듈 자체를 불러오기
# import module1
# print(module1.add(1,3)) # import 를 사용했을 때는 안에 있는 함수를
# print(module1.sub(3,1)) # 모듈명.함수() 를 작성해서 사용한다.

# 2. 모듈 내의 함수만 불러오기
# from module1 import add # module1 속에 있는 add 함수만 가져오기
# print(add(1,3)) # from .. import .. 를 사용하면
                  # module명 없이 바로 함수만 사용 가능
# print(sub(3,1)) # sub는 불러오지 않아서 사용 불가(에러)

# 3. 모듈 내의 여러 개 함수를 불러오기
# from module1 import add, sub
# print(add(1,3))
# print(sub(3,1))

# 4. 모듈 내의 모든 함수(*) 불러오기
# from module1 import *
# print(add(4,5))
# print(sub(5,1))

# 5. 모듈에 별칭(as) 붙이기
# import module1 as mod1 # 모듈명이 너무 길면 별칭을 만들어서 사용 가능
# print(mod1.add(4,6))

# 6. __name__ 사용 ( 메인과 모듈 차이 두기 )
#   현재 실행되는 파일의 __name__ = __main__
#   불러온 모듈의 __name__ = 모듈명
# import module1 as mod1
# print(f"main file : {__name__}")
# print(mod1.add(4,2))

# 7. 변수나 클래스를 불러오기
# import module2 as mod2
# print(mod2.PI)
# modClass = mod2.Math()
# print(modClass.solv(2))
# print(mod2.add(mod2.PI, 4.4)) # js 와 같이 실수 연산이 정확하지는 않다.

# 8. module1.py 파일에
#   1) 2가지 번호를 받는 함수(user_input)를 만든다.
#   2) mul ( 곱셈 ) , div ( 나눗셈 ) 함수를 만든다.
#   3) main파일에는 입력 받은 번호에 따라서 1. add 2. sub 3. mul 4. div 5. end 를 통해
#      각각의 숫자를 입력해서 작동하는 프로그램을 만든다.
#      예시 )
              # 사용할 모드를 입력하세요.
              # 1. add 2. sub 3. mul 4. div 5. end 
              # 모드 입력 >> 1
              # 첫 번째 숫자를 입력하세요 >> 10
              # 두 번째 숫자를 입력하세요 >> 20
              # 10 + 20 = 30 입니다.
              # 사용할 모드를 입력하세요.
              # 1. add 2. sub 3. mul 4. div 5. end 
              # 모드 입력 >> 5
              # 프로그램을 종료합니다.
# from module1 import *
# prompt = """사용할 모드를 입력하세요.
# 1. add 2. sub 3. mul 4. div 5. end"""

# while 1:
#   print(prompt)
#   selectNum = input("모드 입력 >> ")
#   if selectNum == '1':
#     num1, num2 = user_input()
#     print(f"{num1} + {num2} = {add(num1,num2)}")
#   elif selectNum == '2':
#     num1, num2 = user_input()
#     print(f"{num1} - {num2} = {sub(num1,num2)}")
#   elif selectNum == '3':
#     num1, num2 = user_input()
#     print(f"{num1} * {num2} = {mul(num1,num2)}")
#   elif selectNum == '4':
#     num1, num2 = user_input()
#     print(f"{num1} / {num2} = {div(num1,num2)}")
#   elif selectNum == '5':
#     print("프로그램을 종료합니다.")
#     break
#   else :
#     print("입력 값이 잘못되었습니다.")
#     continue

# ----------------------------------------------------------------------------

# 패키지 : 모듈들을 모아놓은 집합(폴더)
#         모듈들을 계층적(폴더 구조)로 관리 가능
#         패키지는 폴더와 파이썬 모듈(파일)로 이루어짐
# 패키지 생성 ( 폴더 생성 )
# game  - __init__.py
#       - graphic - __init__.py
#                 - render.py
#       - sound   - __init__.py
#                 - echo.py
# 패키지 불러오기
# 1. echo 모듈을 import 하여 실행
# import game.sound.echo
# game.sound.echo.echo_test()
# 2. echo 모듈을 별칭 붙여서 실행
# import game.sound.echo as echo
# echo.echo_test()
# 3. echo 모듈을 가진 패키지까지 from 잡고 import로 echo 가져오기
# from game.sound import echo
# echo.echo_test()
# 4. echo 모듈의 echo_test함수를 직접 import 하기
# from game.sound.echo import echo_test
# echo_test()

# 주의사항
# 1. __init__.py 에 정의하지 않은 패키지는 하위 패키지라도 불러올 수 없음
# import game
# game.sound.echo.echo_test() # game 패키지를 불러와도 init에 정의되지 않으면
                              # 하위 패키지이더라도 불러올 수 없다.
# 2. 도트 연산자(.)를 사용해서 import할 때 가장 마지막 항목은 모듈 또는 패키지여야한다.
# import game.sound.echo.echo_test # echo_test는 함수이므로 마지막에 올 수 없다.

# __init__.py
# 정의 : 해당 폴더가 python 패키지임을 인식시켜주는 역할
#        3.4버전 이상부터는 없어도 인식한다. 하위호환용으로 사용
#        패키지 관련 설정이나 초기화 코드를 포함할 수 있다.
# 용도 1. 패키지 단위의 변수 및 함수 정의
# import game
# print(game.VERSION)
# game.print_version_info()
# 용도 2. 패키지 내의 모듈들을 미리 import 한다.
# import game
# game.render_test()
# 용도 3. 패키지의 초기화
# import game
# game.render_test()
# 용도 4. __all__ 변수 사용
#   __all__ 이란 ? (from 패키지 import 모듈)구문으로 불러올 때
#                  모듈 대신에 전체 모듈을 뜻하는 * 을 사용시 불러올 모듈을 
#                  all 에 명시해줘야한다.
# from game.sound import *
# echo.echo_test()  # sound 패키지에 init 에 all 변수를 작성안해주면 에러난다.

# relative 패키지
# HTML 에서 상대경로지정법처럼 패키지를 지정할 수 있다.
# . = 현재 패키지 / .. = 상위 패키지
# 예제 ) graphic 패키지의 render.py 에서 echo_test함수를 사용할 때
#     상위 예제는 game/graphic/render.py 에 작성함

# 주의사항 ) from ... import ... 구문에서만 사용가능하다.
# from game.graphic.render import render_test
# render_test()

# ----------------------------------------------------------------------
# arithmetic  - basic_operator.py       ( 덧셈 뺄셈 곱셈 나눗셈 )
#             - developer_operator.py   ( 나머지, 몫, 거듭제곱 )
# shape       - circle_area.py          ( 원의 넓이 )
#             - square_area.py          ( 사각형 넓이 )
# [실행결과]
# 사용할 연산을 선택하세요
# 1. 기본연산 2. 개발자연산 3. 원의 넓이 4. 사각형의 넓이 5. 종료
# 연산 선택 >> 1
# 기본 연산 중에서 사용할 연산을 선택하세요.
# 1. 덧셈 2. 뺄셈 3. 곱셈 4. 나눗셈 5. 이전으로
# 연산 선택 >> 1
# 첫 번째 숫자 입력 >> 10
# 두 번째 숫자 입력 >> 20
# 10 + 20 = 30 입니다. 
# 사용할 연산을 선택하세요
# 1. 기본연산 2. 개발자연산 3. 원의 넓이 4. 사각형의 넓이 5. 종료
# 연산 선택 >> 5
# 프로그램을 종료합니다.
# from arithmetic import *
# from shape import *

# def userNumInput2():
#   num1 = input("첫 번째 숫자(가로) >> ")
#   num2 = input("두 번째 숫자(세로) >> ")
#   return int(num1) , int(num2)
# def userNumInput1():
#   num1 = input("반지름 >> ")
#   return int(num1)
# first_prompt = """사용할 연산을 선택하세요
# 1. 기본연산 2. 개발자연산 3. 원의넓이 4. 사각형의넓이 5. 종료"""
# basic_prompt = """기본연산 중에서 사용할 연산을 선택하세요
# 1. 덧셈 2. 뺄셈 3. 곱셈 4. 나눗셈 5. 이전으로"""
# developer_prompt = """개발자 연산 중에서 사용할 연산을 선택하세요
# 1. 나머지 2. 몫 3. 거듭제곱 4. 이전으로"""

# while 1:
#   print(first_prompt)
#   firstSelect = input("연산 선택 >> ")
#   if firstSelect == '1':
#     while 1:
#       print(basic_prompt)
#       basicSelect = input("연산 선택 >> ")
#       if basicSelect == '1':
#         num1, num2 = userNumInput2()
#         print(f"{num1} + {num2} = {basic_operator.add(num1,num2)}")
#       elif basicSelect == '2':
#         num1, num2 = userNumInput2()
#         print(f"{num1} - {num2} = {basic_operator.sub(num1,num2)}")
#       elif basicSelect == '3':
#         num1, num2 = userNumInput2()
#         print(f"{num1} * {num2} = {basic_operator.mul(num1,num2)}")
#       elif basicSelect == '4':
#         num1, num2 = userNumInput2()
#         print(f"{num1} / {num2} = {basic_operator.div(num1,num2)}")
#       elif basicSelect == '5':
#         print("처음으로 돌아갑니다.")
#         break
#       else:
#         print("입력 값이 잘못되었습니다. 다시 입력해주세요.")
#         continue
    
#   elif firstSelect == '2':
#     while 1:
#       print(developer_prompt)
#       developerSelect = input("연산 선택 >> ")
#       if developerSelect == '1':
#         num1, num2 = userNumInput2()
#         print(f"{num1} % {num2} = {developer_operator.rem(num1, num2)}")
#       elif developerSelect == '2':
#         num1, num2 = userNumInput2()
#         print(f"{num1} // {num2} = {developer_operator.share(num1, num2)}")
#       elif developerSelect == '3':
#         num1, num2 = userNumInput2()
#         print(f"{num1} ** {num2} = {developer_operator.power(num1, num2)}")
#       elif developerSelect == '4':
#         print("처음으로 돌아갑니다.")
#         break
#       else:
#         print("입력 값이 잘못되었습니다. 다시 입력해주세요.")
#         continue
#   elif firstSelect == '3':
#     r = userNumInput1()
#     print(f"반지름 {r} 인 원의 넓이 : {circle_area.circle_area(r)}")
#   elif firstSelect == '4':
#     width, height = userNumInput2()
#     print(f"가로 : {width} / 세로 : {height} 인 사각형의 넓이 : {square_area.square_area(width, height)}")
#   elif firstSelect == '5':
#     print("프로그램을 종료합니다.")
#     break
#   else:
#     print("입력 값이 잘못되었습니다. 다시 입력해주세요.")
#     continue

# 문제
# 근속 연수를 입력하면 10년~20년 사이의 사원에게 해외여행의 기회를 주려고 한다.
# [조건]
# 10년 이상 15년 미만 : 중국
# 15년 이상 18년 미만 : 호주
# 18년 이상 20년 이하 : 유럽
# 근속연수를 15~20 사이의 숫자를 입력하지 않으면 end를 출력하고 종료
# [실행결과]
# 근속연수 >> 12
# 중국
# 근속연수 >> 15
# 호주
# 근속연수 >> 20
# 유럽
# 근속연수 >> 5
# End
while True:
  years = int(input("근속연수 >> "))
  if years >= 10 and years < 15:
    print("중국")
  elif years >= 15 and years < 18:
    print("호주")
  elif years >= 18 and years <= 20:
    print("유럽")
  else:
    print("End")
    break