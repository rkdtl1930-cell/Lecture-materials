// 파일명 : js_grammer.js

// 변수란 ? 데이터를 담는 공간
// let 변수 선언 및 할당 ( let 변수명 )
let varName; //varName이라는 변수를 선언
varName = "이름"; // varName에 데이터를 저장(할당)
// 선언 및 할당을 한번에 - 초기화했다.
let varName2 = "이름";
// ex ) 가로너비 세로높이를 지정하여 넓이를 콘솔에 출력하시오.
let width;
let height;
width = 200;
height = 50;
let area = width * height;
console.log(`넓이는 ${area} 입니다.`);

// 상수란 ? 바뀌지 않는 값
// 상수는 const 변수로 선언한다. ( const 변수명 )
const PI = 3.141592;
let radius = 5;
let area2 = PI * radius * radius;
console.log(`원의 넓이는 ${area2} 입니다.`);

// 자료형 확인 방법 
//  > typeof 데이터 

// 숫자형(integer) 확인
console.log(typeof 100);  // 정수
console.log(typeof 3.14); // 실수
console.log(0.1 + 0.2);   // js는 실수형 계산을 정밀하게 하지 못한다.

// 문자열 확인
console.log(typeof "문자"); // 문자열
console.log(typeof '문자'); // 문자열
console.log("I\'m studing js"); // 특수문자 작성할 때 역슬래쉬(\)+특수문자하면 된다.
// 문자열(string) - 템플릿 리터럴
// 템플릿 리터럴 ? 문자열, 변수, 특수문자를 한 번에 작성 가능
// 백틱(``) 사이에 작성 / 변수는 ${변수명} 으로 작성 가능
let name = "헬로헬로";
console.log(`${name} : "안녕하세요?" 이라고 말했다.`);

// 논리형(boolean) - true / false 만 데이터로 가진다.
console.log(typeof true);
console.log(typeof false);

// undefined : 변수가 선언이 되었지만, 값이 할당되지 않은 상태
// null : 변수가 선언도 되고, 할당도 되었지만 값이 유효하지 않은 상태

// 배열(array) : 하나의 변수에 여러 값을 저장할 수 있는 복합 유형
let season = ["봄", "여름", "가을", "겨울"];  // 배열 선언
console.log(season); // -> 0 : 봄 / 1 : 여름 / 2 : 가을 / 3 : 겨울
                     // 위에 적힌 0~3 은 index 라고 한다.
console.log(season[0]); // index를 이용해서 배열의 값 중 하나를 가져오기.
console.log(season.length); // 배열의 총 갯수를 가져오기.

// 자료형 변환하기 - 느슨한 자료형 체크
let variable;
variable = 10;
console.log(typeof variable);
variable = "글자";
console.log(typeof variable);

// 자료형 변환하기 - 자동 형 변환
let input = "10"; // 원래 prompt였는데, 창이 계속 떠서 바꿈.
console.log(typeof input); // prompt로 받은 값은 string 으로 읽힌다.
let mul = input * 10;
console.log(typeof mul); // string * number 가 되면 string 은 number로 바뀐다.

let one = '20'; // string
let two = 10; // number
console.log(one + two); // number였던 two 변수가 string으로 바껴서 2010 이 나온다.
console.log(one - two); // string이었던 one 변수가 number로 바껴서 10 이 나온다.
console.log(one / two ); // string이었던 one 변수가 number로 바껴서 2 가 나온다.
// 위의 연습을 정리하면 + 제외하고는 string이 number로 바뀐다.

// 자료형 변환 함수
// Number() - 문자열이나 논리형 값을 숫자로 변경
// parseInt() - 문자열을 정수 숫자로 변경
// parseFloat() - 문자열을 실수 숫자로 변경
// String() - 숫자나 논리형을 문자열로 변환
// Boolean() - 괄호 안의 값을 논리형으로 변환
console.log('Number() 함수 사용');
console.log(Number('123'));
console.log(Number('123ABC'));

console.log('parseInt() 함수 사용');
console.log(parseInt('123'));
console.log(parseInt('123.45'));
console.log(parseInt('1234A1BC'));
console.log(parseInt('ABC123'));

console.log('parseFloat() 함수 사용');
console.log(parseFloat('123'));
console.log(parseFloat('123.45'));
console.log(parseFloat('123ABC'));
console.log(parseFloat('ABC123'));

console.log('String() 함수 사용')
console.log(String(123));
console.log(String(true));

console.log('Boolean() 함수 사용');
console.log(Boolean(1));
console.log(Boolean(0));
console.log(Boolean('abc'));
console.log(Boolean(''));
// Boolean 자료형은 0 또는 '값이없음' 이면 false 이고 이외의 모든 값은 true 이다.

// 연산자
/* 1. 산술 연산자
      + : 더하기
      - : 빼기
      * : 곱하기
      / : 나눈 값
      % : 나눈 나머지
      ++ : 피연산자를 1 증가
      -- : 피연산자를 1 감소
*/
console.log("연산자");
let numberOne = 15;
let numberTwo = 2;
console.log(numberOne / numberTwo);
console.log(numberOne % numberTwo);
console.log(numberOne++);
console.log(numberOne--);
console.log(++numberOne);
console.log(--numberOne);
// ++ 과 -- 는 앞과 뒤에 위치할 수 있으며,
// 앞에 위치한다면 명령을 실행시키기 전에 +- 1 이 되고,
// 뒤에 위치한다면 명령을 먼저 실행시키고 다음 명령이 되기 전에 +- 1 이 된다.

/* 2. 할당 연산자(대입 연사자) 
      =   : 연산자 오른쪽 값을 왼쪽 변수에 할당 ( y = x + 3 )
      +=  : y += x 일 때, y = y + x 를 의미한다.
      -=  : y -= x 일 때, y = y - x 를 의미한다.
      *=  : y *= x 일 때, y = y * x 를 의미한다.
      /=  : y /= x 일 때, y = y / x 를 의미한다.
      %=  : y %= x 일 때, y = y % x 를 의미한다.
*/

/* 3. 비교 연산자 ( 결과값이 true 또는 false )
      <   : 크다
      <=  : 크거나 같다
      >   : 작다
      >=  : 작거나 같다
      ==  : 값이 같다
      !=  : 값이 다르다
      === : 값도 같고, 자료형도 같다. ( and )
      !== : 값이 같지 않거나, 자료형이 같지 않다. ( or )
*/
console.log("==과 ===, != 와 !== 의 차이")
console.log( 3 == "3" );
console.log( 3 != "3" );
console.log( 3 === "3");
console.log( 3 !== "3");

/* 4. 논리 연산자 ( 결과값이 true / false 이다.)
      OR연산자 ( || ) - a || b 일 때, a 이거나 b 이거나
      AND연산자 ( && ) - a && b 일 때, a 이고, b 이다.
      NOT연산자 ( ! ) - !a 일 때, a의 반대
*/
console.log("논리 연산자 확인");
console.log( 10 > 11 || 10 < 11 );
console.log( 10 > 11 && 10 < 11 );
console.log( !(10 > 11) );
