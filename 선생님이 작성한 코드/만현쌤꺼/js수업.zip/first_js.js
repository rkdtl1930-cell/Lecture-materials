// 파일명 : first_js.js
var heading = document.querySelector('#heading');
heading.onclick = function(){
  heading.style.color = "red";
}

var alert1 = document.querySelector("#alert");
alert1.onclick = function(){
  // 알림 통보하는 알림창
  alert("알림 창 입니다.");
}
var confirm1 = document.querySelector("#confirm");
confirm1.onclick = function(){
  // Yes or No가 가능한 확인 받는 창
  confirm("확인창 입니다.");
}
var prompt1 = document.querySelector("#prompt");
var answer = "";
prompt1.onclick = function(){
  // 내용을 작성할 수 있는 프롬프트 창
  answer = prompt("작성 가능한 프롬프트 창 입니다.");
  // document.write("<b>"+ answer + "<b>님, 환영합니다.");
  console.log(answer + "님 반갑습니다.");
  console.log(`${answer}님 반갑습니다.`);
}

// 입출력
// 1. document.write() - body 부분에 작성하게 된다.
//    > 페이지가 load 되고 난 후에 document.write()가 실행되면 html이 모두 지워진다.
//    > 사용시에는 위의 주의점을 확인해야한다.
// let name = prompt("이름을 작성해주세요.");
// document.write("<br><b>"+name+"</b>님, 환영합니다.");

// 2. console.log() - 개발자도구의 console 부분에 출력된다.
console.log("안녕하세요?");