# from game.sound.echo import echo_test  일반적인 패키지-모듈-함수 불러오기
from ..sound.echo import echo_test

def render_test():
  print("render.py : render_test")
  echo_test()