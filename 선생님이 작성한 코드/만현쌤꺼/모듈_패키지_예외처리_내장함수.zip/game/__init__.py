from game.graphic.render import render_test

VERSION = 3.5

def print_version_info():
  print(f"This Game Version : {VERSION}")

# 패키지 초기화 코드 아래에 작성
print("Game Initializing ....") 