def square_area(width, height):
  return width * height