# 파일명 : 08_except_innerFunction.py

# 예외처리 : 예상되는 에러를 잡아준다.

# 예외처리를 해주는 이유 : 프로그램을 죽이지 않고 계속 실행을 유지하게 하려고 사용한다.

# 1. try - except 구문
#     try : 명령문
#     except : try 구문에서 에러가 날 경우 실행하는 명령
try:
  4 / 0
except:
  print("에러")
# except 구문에는 예상가능한 에러를 지정해서 받을 수 있다.
try:
  a = [0,1,2]
  print(a[3])
except IndexError:
  print("에러에러에러에러에러에러")
# except 구문에 예상 가능한 에러를 변수처리 가능
try:
  a = [0,1,2]
  print(a[3])
except IndexError as e:
  print(e)

# try - finally 구문
#     finally 구문 : try에서 에러가 있어도, 없어도 finally구문을 수행한다.
try:
  # 예제) 파일을 열고, 아래의 구문을 수행하다가 에러 났을 경우 finally 에서 파일을 닫는다.
  a = [0,1,2]
  print(a[3])
  print("HELLO")
except IndexError as e:
  print(e)
finally:
  print("BYE")

# try - except - else 구문
#   try 구문에서 실행하다가 에러가 있으면 except 구문 실행, 에러가 없으면 else 구문 실행
# 나이를 입력 받아서 18세 이상이면 '성인은 출입가능' 출력
#                   18세 미만이면 '미성년자 출입금지' 출력
#                   숫자가 아닌 다른 글을 입력하면 except구문으로 '입력이 정확하지않다' 출력
#                   숫자가 입력되면 else문으로 가서 위의 첫번째 두번째 조건에 의해 출력
# while 1:
#   try:
#     age = int(input('나이를 입력하세요'))
#   except:
#     print('입력이 정확하지 않습니다.')
#   else:
#     if age == 0:
#       print("종료")
#       break
#     elif age <= 18:
#       print('미성년자 출입금지')
#     else:
#       print('성인은 출입가능')

# except 에 여러 에러를 지정하기
try:
  a = [0,1,2]
  4 / 0
  print(a[3])
except ZeroDivisionError:
  print("0으로 나눌 수 없다")
except IndexError:
  print("지정된 Index 범위를 벗어났다.")

try:
  a = [0,1,2]
  4 / 0
  print(a[3])
except ( ZeroDivisionError, IndexError ) as e:
  print(e) # 지정한 두개의 에러 중 발생된 에러를 기준으로 출력한다.

# 오류 회피하기 ( pass 키워드 사용 )
try:
  a = [0,1,2]
  print(a[3])
except:
  pass
print("오류 뛰어넘고 그냥 실행하기")

# 오류 일부러 발생시키기 ( raise 키워드 )
# 부모클래스에서 메소드를 만들고, 각각의 자식클래스가 사용하는 부모클래스의 메소드가 다 다를때
# 무조건 재정의를 하게 만들고 싶을 때 주로 사용.
class Bird:
  def fly(self):
    raise NotImplementedError # 지정한 에러가 발생한다.

class Eagle(Bird):
  def fly(self):
    print("위잉위잉")

eagle = Eagle()
eagle.fly()

# 예외(에러) 만들기
class MyError(Exception):
  def __str__(self):
    return "정상적이지 않은 문구가 들어왔습니다."

def say_nick(nick):
  if nick == "바보":
    raise MyError() # "바보" 라는 인수가 들어온다면 MyError()의 에러를 발생시킨다
  print(nick)

try:
  say_nick("천사")
  say_nick("바보")
except MyError as e:
  print("허용되지 않은 별명 입니다.")
  print(e)

# while True:
#   try:
#     years = int(input("근속연수 >> "))
#   except:
#     print("숫자만 입력해주세요.")
#   else:
#     if years >= 10 and years < 15:
#       print("중국")
#     elif years >= 15 and years < 18:
#       print("호주")
#     elif years >= 18 and years <= 20:
#       print("유럽")
#     else:
#       print("End")
#       break

# ----------------------------------------------------------------------------------------
# 파이썬 내장함수
#     모듈과 달리 import 할 필요 없이 바로 사용 가능한 함수들
#     iterable : 반복 가능한 데이터 ( 문자열, 리스트, 튜플 등등 )
#     f : 함수
#     object : 객체
# <<< 숫자 관련한 내장함수 >>> 
# 1. pow( x, y ) - x 의 y 제곱승
print(pow(2, 5))
# 2. divmod(x, y) - x를 y로 나눴을 때, 몫과 나머지를 튜플 형태로 리턴
print(divmod(14,3))
# 3. sum(iterable) - 반복 가능한 데이터(iterable)을 인수로 안에 적힌 값들을 모두 더한다.
print(sum([1,2,3,4,5]))
# 4. round(x, 소수점자리) - x 를 소수점자리 밑에서 반올림 리턴
print(round(5.5)) # 소수점자리를 입력하지 않으면 1의 자리수로 반올림
print(round(5.56441,3)) # 소수점자리를 입력하면 그 자리수로 반올림

# <<< 문자 관련한 내장함수 >>>
# 1. ord(c) - c 라는 문자를 넣으면 그 문자에 해당하는 유니코드 번호를 알려준다.
print(ord('x'))
# 2. chr(i) - i 라는 숫자를 넣으면 그 유니코드에 해당하는 문자를 알려준다.
print(chr(120))
# 3. eval(문자열) - 문자열로 구성된 표현식을 입력하면 그 표현식을 실행한 결과를 알려준다.
str1 = "1 + 5"
print(eval(str1))

# <<< 논리(T/F) 관련한 내장함수 >>>
# 1. all(iterable) - 반복가능한데이터의 값 중 하나라도 거짓이면 false를 출력
arr1 = [1,2,3,4,5,0]
arr2 = [1,2,3,4,5]
print(all(arr1)) # 0 이 있어서 False
print(all(arr2)) # 0 이 없으니 모두 True
# 2. any(iterable) - 반복가능한데이터의 값 중에서 하나라도 진실이면 True를 출력
arr1 = ["", 0, None, 1]
arr2 = ["", 0, None]
print(any(arr1)) # 1 이 있어서 True를 반환
print(any(arr2)) # 모두 False라서 False를 반환

# <<< 객체 관련한 내장함수 >>>
class testClass:
  def add(a,b):
    return a + b
tc = testClass()
arr1 = [1,2,3]
# 1. len(object) 객체의 요소 전체의 갯수를 리턴
print(len(arr1)) 
# 2. type(object) 객체의 자료형(클래스)을 반환
print(type(tc))
# 3. id(object) 객체가 저장된 메모리 주소를 반환
print(id(tc))
# 4. dir(object) 객체가 사용가능한 변수나 함수를 보여준다.
print(dir(tc))
# 5. isinstance(object, class) - 객체가 클래스의 인스턴스인지 판단
print(isinstance(tc, testClass)) # 인스턴스란 ? 클래스를 틀로 만든 객체들을 지칭한다.

# <<< 미분류 내장함수 >>>
# 1. input() - 사용자가 입력 하는 함수
# 2. enumerate(iterable) - 순서가 있는 데이터를 입력으로 받아 인덱스 값을 포함하는 객체로 반환
arr1 = ["a", "b", "c", "d"]
# for i, char in arr1:  # enumarate를 사용하지 않고 i 를 출력하면 에러.
#   print(i , char)
for index, char in enumerate(arr1):
  print( index , char )
# 3. filter(f, iterable) - 반복 가능한 데이터의 요소 순서대로 함수를 호출했을 때 리턴이 참인 것만 반환
def positive(x):
  return x > 0
print(list(filter(positive, [1, -3, 2, 0, -5, 6])))
print(list(filter(lambda x : x > 0, [1, -3, 2, 0, -5, 6])))
# 4. map(f, iterable) - 입력받은 데이터의 요소들을 함수 f에 적용한 값을 리턴
def mul_2(x):
  return x * 2
print(list(map(mul_2, [1,2,3,4])))
print(list(map(lambda x: x * 2, [1,2,3,4])))
# 5. zip(*iterable) - 동일한 갯수로 이루어진 데이터들을 같은 위치의 요소끼리 묶어서 리턴
print(list(zip([1,2,3],[4,5,6])))
print(list(zip([1,2,3],[4,5,6],['a','b','c'])))
print(list(zip("abc", "def")))