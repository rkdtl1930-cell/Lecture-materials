# module1.py
# add 와 sub 함수 생성
def user_input():
  num1 = input("첫 번째 숫자를 입력하세요 >> ")
  num2 = input("두 번째 숫자를 입력하세요 >> ")
  return int(num1), int(num2)
def add(a,b):
  return a + b
def sub(a,b):
  return a - b
def mul(a,b):
  return a * b
def div(a,b):
  return a / b

print(f"module1 : {__name__}")

if __name__ == '__main__':
  print("현재 파일 초기화 중")