# %%
# 부분 적으로 코딩을 할 때 사용
# 기본적으로 작성하면 파일 실행을 눌러야하지만
# 부분적으로 실행할 때는 ctrl + enter 단축키
# 다음 부분을 만들 때는 alt + enter 단축키

# 1. 변수 선언
# 동적 타이핑 언어로서 실행 시점에 파이썬 스스로 메모리를 잡는다.
a = 1
b = "aaa"
print(a)
print(b)

# 2. 자료형
#   type() 함수를 사용해서 자료형 확인 가능
a = 1
b = 1.1234
c = "1234"
d = True
print(type(a)) #정수 integer ( int )
print(type(b)) #실수 floating-point (float)
print(type(c)) #문자열 string ( str )
print(type(d)) #불리안 boolean ( bool )

e = 0b1001 #2진수
f = 0o1001 #8진수
g = 0x1001 #16진수
print(e)
print(f)
print(g)

# 3. 연산
print( 30 / 5 ) # 나눗셈을 진행하면 자동으로 실수로 형 변환
print( 3 ** 5 ) # n의 m승 제곱승 사용법
print(7 // 2)   # // 연산은 나누기의 몫
print(7 % 2)    # % 연산은 나누기의 나머지

# 변수 본인을 연산할 때 ( += , -= , *= , /= )
a = 10
a += 1
print("a += 1 : %d" % a)
a -= 1
print("a -= 1 : %d" % a)
a *= 2
print("a *= 2 : %d" % a)
a /= 2
print("a /= 2 : %d" % a)

# 비트연산 ( &, | , ^ , ~ , << , >> )
a = 0b1010 # 2진수 : 1010 / 10진수 : 10
b = 0b0111 # 2진수 : 0111 / 10진수 : 7

print(a&b) # 2진수 : 0010 / 10진수 : 2  두 피연산자가 1일 때 1출력
print(a|b) # 2진수 : 1111 / 10진수 : 15 두 피연산자 중 하나 또는 둘 다 1 일 때 1 출력
print(a^b) # 2진수 : 1101 / 10진수 : 13 두 피연산자의 종류가 다를 때 1 출력
print(~a)  # not의 경우에는 2의보수 개념이 들어가야함 ( 개인적으로,,, )
print(a>>1)# 1칸 오른쪽으로 비트 이동 ( 0101 )
print(a<<1)# 1칸 왼쪽으로 비트 이동 ( 10100 )

# 형변환
# float() : 문자열 또는 정수를 실수형으로 변경
# int()   : 문자열 또는 실수를 정수형으로 변경
# str()   : 정수 또는 실수 또는 불리안 형을 문자열로 변경
a = 1   # 정수형
b = "1" # 문자열형
# print( a + b )  정수형 + 문자열형 -> 에러 표시 ! 자료형이 안맞춰있다. 
print( a + int(b) ) # 위 코드는 에러 나기 때문에 형 변환이 이루어져야한다.
print( str(a) + b ) # 피연산자의 자료형을 맞춰줘야한다.

# 멤버 연산자 ( in / not in )
# in : 왼쪽의 피연산자가 오른쪽의 피연산자 안에 포함되어있는지
a = 3
b = [1,3,5,7,9]
print( a in b )
print( a not in b )

# 자료형을 확인하는 함수 ( type() )
# type() 함수에 인수로 변수를 넣으면 그 변수의 자료형을 알려준다.
print(type(a))
print(type(b))

# %%

# 문자열 관련
# 1. 작성법 ('문자열', "문자열" , '''문자열''', """문자열""")
# 2. 여러 줄을 작성 ( '''문자열''', """문자열""", 이스케이프코드 \n 을 삽입)
str1 = '''안녕
하
세요'''
str2 = '안녕\n하\n세요'
print(str1)
print(str2)
# 3. 문자열 연산 ( + , * )
str1 = "abc"
str2 = "xyz"
print(str1 + str2) # 이어 붙이기
print( str1 * 3 )  # 자신을 여러번 붙이기
# 4. 문자열 인덱싱
# 문자열 자체를 인덱스화가 가능
str1 = "abcdefg"
print(str1[0])
# 문자열 슬라이싱 ( 문자열을 잘라낸다 )
# 문자열변수명[start : end : step]
str2 = "20250804Rainy"
date = str2[:8] # 0번부터 8번 전까지
weather = str2[8:] # 8번부터 끝까지
print(date)
print(weather)
print(str1[2:6:2]) # 2번부터 6번전까지 2칸씩

# 문자열 포매팅 ( 포맷 코드를 사용해서 값을 대입 )
# %s(문자열) %c(문자1개) %d(정수) %f(실수) %o(8진수) %x(16진수) %%(%출력)
name = "홍길동"
age = 30
print("안녕하세요. 저는 %s 입니다." % name)
print("안녕하세요. %d 살 %s 입니다." % (age, name))
print("%o and %x" %(0o1001, 0x1001))
# 정렬과 공백 넣어서 자리수 맞춰주기
print("%s" % "HELLO")
print("%10s" % "HELLO") # 자리수를 10자로 맞추고, 우측정렬
print("%-10s" % "HELLO")# 자리수를 10자로 맞추고, 좌측정렬
print("%0.4f" % 3.412341234) # 자리수를 소수점 이하 4자리만 보이게한다. 이때, 5자리에서 반올림한다.

# 문자열 포매팅2 ( format() 함수를 이용 )
# {숫자}로 자리를 맞추고 .format()에 인수로 각 숫자에 값을 넣음
print("안녕하세요. 저는 {0} 입니다.".format(name))
print("안녕하세요. 저는 {0}살 {1}입니다.".format(age, name))
# 이름으로 작성하기
print("i ate {number} apples.".format(number=10))
# 자릿수 지정해주기
print("{0:<10}".format("hi")) # 10자리수 중 왼쪽정렬
print("{0:>10}".format("hi")) # 10자리수 중 오른쪽정렬
print("{0:^10}".format("hi")) # 10자리수 중 가운데정렬
# 빈자리에 문자 채우기
print("{0:=^10}".format("hi"))# 10자리수 중 가운데정렬 빈공간은 = 을 넣는다
# 소수점 자리수 
print("{0:0.4f}".format(3.123555)) # 소수점이하 4자리만 , 5자리반올림
print("{0:=>10.4f}".format(3.12345)) # 총 10자리 수 소수점은 4자리
                                     # 빈자리가 4개가 남는다
print("{0:b} and {1:o} and {2:x}".format(5, 10, 20)) # 2진수, 8진수, 16진수

# 문자열 포매팅3 ( f 문자열 포매팅 - 파이썬3.6버전 이상부터 사용가능 )
# {변수} 를 사용해서 변수의 값을 문자열에 넣을 수 있다.
print(f"안녕하세요. 저는 {name}입니다.")
print(f"안녕하세요. 저는 {age}살 {name}입니다.")
# 자리 수 맞추기( 빈자리 문자넣기 ) & 소수 자리수도 format() 사용할때와 동일
print(f"{'hi':=<10}")

# 문자열 관련 함수들
testStr = "abcdefghijklmnopqrstuvwxyz"
print(testStr.count('b')) # 문자열.count(문자) 인수로 넣는 값이 문자열에 몇개가 있는지 출력
print(",".join(testStr)) # 문자.join(문자열) 인수로 넣는 문자열 사이에 문자를 삽입한다
                         # 구분자 지정할때 많이 사용
print(testStr.find('e')) # 문자열.find(문자) 인수로 넣은 문자를 문자열에서 인덱스 값으로 찾아 출력
                         # 단, 찾으려는 문자가 없으면 에러를 띄운다.
# 문자열.upper() / 문자열.lower() - 문자열을 대문자/소문자로 변경
testStr2 = "   abc   "
print(testStr2.lstrip()) #문자열.lstrip() 문자열의 왼쪽 공백을 모두 삭제
print(testStr2.rstrip()) #문자열.rstrip() 문자열의 오른쪽 공백을 모두 삭제
print(testStr2.strip())  #문자열.strip() 문자열의 양쪽 공백을 모두 삭제

testStr3 = "Life is too short"
print(testStr3.replace("Life", "Your leg")) # 문자열.replace(문자열1, 문자열2) 문자열의 문자열1 을 문자열2 로 대체한다.
print(testStr3.split())  # 문자열.split() 공백을 기준으로 문자를 나눠서 리스트로 만듬
testStr4 = "a:b:c:d"
print(testStr4.split(":")) # split() 함수에 인수(문자)가 들어가면 그 인수를 기준으로 나눠서 리스트로 만듬
print(len(testStr4)) # len(문자열) 인수로 넣은 문자열의 길이를 출력
# %%
string1 = "Hello this is Apple"
# 1. 위 문자열에서 is 만 출력하기 ( 2가지 방법 )
print(string1[11:13]) # 1. 문자열 슬라이싱
print(string1.split()[2]) # 2. split 함수 사용해서 인덱스 불러오기

# 2. 위 문자열에서 Apple를 Banana로 변경하기
print(string1.replace("Apple", "Banana"))

# 3. hobby 변수와 name 변수를 사용해서 나는 name 입니다. 취미는 hobby 입니다. 출력해보기
name = "홍길동"
hobby = "아무것도안하기"
print("나는 %s 입니다. 취미는 %s 입니다." %(name, hobby))
print("나는 {0} 입니다. 취미는 {1} 입니다.".format(name, hobby))
print(f"나는 {name} 입니다. 취미는 {hobby} 입니다.")

# 4. string1 문자열에서 i 가 몇 개 나오는 지 출력하기
print(string1.count("i"))

# 5. string1 문자열에 "and this is banana" 문자열을 더해서 출력하기
print(string1 + " and this is banana")

# 6. "busan" 의 문자열을 출력하는데 자리수를 10자리 가운데 정렬 빈자리는 ! 넣기
print(f"{"busan":!^10}")
print("{0:!^10}".format("busan"))
