package dao;

import common.MysqlConnect;
import dto.Member;

public class MemberDAOMysql extends MysqlConnect {
	public MemberDAOMysql() {}
	public MemberDAOMysql(String drv, String url, String id, String pw) {
		super(drv,url,id,pw);
	}
	
	public Member getMember(String uid, String upass) {
		Member mem = new Member();
		String sql = "select * from member where id=? and pass=?";
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, uid);
			ps.setString(2, upass);
			rs=ps.executeQuery();
			
			if(rs.next()) {
				mem.setId(rs.getString("id"));
				mem.setPass(rs.getString("pass"));
				mem.setName(rs.getString("name"));
				mem.setRegidate(rs.getDate("regidate"));
			}
		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			close();
		}
		
		return mem;
	}
}
